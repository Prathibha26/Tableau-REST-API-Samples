# Tableau-REST-API-samples
basicEmbed.html - js code Embed a visualization in a div element.
getDataBasic.html - js code Get the underlying data for the currently displayed viz.
